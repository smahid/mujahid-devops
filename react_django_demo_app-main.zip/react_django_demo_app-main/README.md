# react_django_demo_app
A demo app for React and Django Deployment

docker-compose down
docker-compose up -d
